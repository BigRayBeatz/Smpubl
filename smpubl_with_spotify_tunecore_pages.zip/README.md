
# SMPUBL GitHub Pages Site

This repository hosts the SMPUBL landing page with links to Spotify and TuneCore.

## Pages Included
- `index.html` — Main landing page
- Hosted via GitHub Pages: `https://yourusername.github.io/smpubl`
